﻿using System;

// Interface 1 : Pass
interface Pass
{
    bool PassStudent(int mark);
}

// Interface 2 : Division
interface Division
{
    string GetDivision(int average);
}

// Class implementing both interfaces
class Result : Pass, Division
{
    // Pass Method
    public bool PassStudent(int mark)
    {
        if (mark >= 50)
            return true;
        else
            return false;
    }

    // Division Method
    public string GetDivision(int average)
    {
        if (average >= 70)
            return "Distinction";
        else if (average >= 60)
            return "First Class";
        else if (average >= 50)
            return "Second Class";
        else
            return "Fail";
    }
}

// Main Class
class Program
{
    static void Main()
    {
        Result r = new Result();

        Console.Write("Enter Marks: ");
        int marks = Convert.ToInt32(Console.ReadLine());

        bool result = r.PassStudent(marks);

        if (result)
        {
            Console.WriteLine("Student Passed");
            Console.WriteLine("Division: " + r.GetDivision(marks));
        }
        else
        {
            Console.WriteLine("Student Failed");
        }
    }
}