﻿using System;

class Program
{
    static void Main()
    {
        int intNumber = 20;      
        float floatNumber = 12.75f;

       
        float autoConversion = intNumber;

        
        int forceConversion = (int)floatNumber;

        Console.WriteLine("Integer Value: " + intNumber);
        Console.WriteLine("Float Value: " + floatNumber);

        Console.WriteLine("\nAutomatic Conversion (int to float): " + autoConversion);
        Console.WriteLine("Force Conversion (float to int): " + forceConversion);
    }
}
