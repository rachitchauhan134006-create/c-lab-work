﻿using System;

class Program
{
    static void Main()
    {
        string correctUsername = "admin";
        string correctPassword = "1234";
        string username, password;
        int attempts = 3;

        while (attempts > 0)
        {
            Console.Write("Enter Username: ");
            username = Console.ReadLine();

            Console.Write("Enter Password: ");
            password = Console.ReadLine();

            if (username == correctUsername && password == correctPassword)
            {
                Console.WriteLine("Login Successful");
                break;
            }
            else
            {
                attempts--;
                Console.WriteLine("Invalid Credentials");
                Console.WriteLine("Attempts Left: " + attempts);
            }
        }

        if (attempts == 0)
        {
            Console.WriteLine("Account Locked");
        }
    }
}
