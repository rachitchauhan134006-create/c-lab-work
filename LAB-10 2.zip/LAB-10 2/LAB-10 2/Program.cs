﻿using System;

class LoanCheck
{
    static void Main()
    {
        Console.Write("Enter age: ");
        int age = int.Parse(Console.ReadLine());

        Console.Write("Enter income: ");
        int income = int.Parse(Console.ReadLine());

        Console.Write("Enter credit score: ");
        int score = int.Parse(Console.ReadLine());

        if (age >= 21)
        {
            if (income >= 20000)
            {
                if (score >= 650)
                    Console.WriteLine("Loan Approved");
                else
                    Console.WriteLine("Low Credit Score");
            }
            else
                Console.WriteLine("Income Too Low");
        }
        else
            Console.WriteLine("Age Not Eligible");
    }
}