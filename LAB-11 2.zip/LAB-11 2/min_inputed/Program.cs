﻿using System;

class MinNumber
{
    static void Main()
    {
        Console.Write("How many numbers you want to enter: ");
        int n = int.Parse(Console.ReadLine());

        int min = int.MaxValue;

        for (int i = 1; i <= n; i++)
        {
            Console.Write("Enter number " + i + ": ");
            int num = int.Parse(Console.ReadLine());

            if (num < min)
                min = num;
        }

        Console.WriteLine("Minimum number is: " + min);
    }
}