﻿using System;

class Program
{
    static void Main()
    {
        int n, a = 0, b = 1, sum;

        Console.Write("Enter a number: ");
        n = Convert.ToInt32(Console.ReadLine());

        Console.Write("Fibonacci Series: ");

        while (a <= n)
        {
            Console.Write(a + " ");
            sum = a + b;
            a = b;
            b = sum;
        }
    }
}
