﻿using System;

interface Pass
{
    bool PassMarks(int mark);
}

interface Division
{
    string DivisionMarks(int average);
}

class Result : Pass, Division
{
    public bool PassMarks(int mark)
    {
        if (mark >= 50)
            return true;
        else
            return false;
    }

    public string DivisionMarks(int average)
    {
        if (average >= 60)
            return "First Division";
        else if (average >= 50)
            return "Second Division";
        else if (average >= 40)
            return "Third Division";
        else
            return "Fail";
    }
}

class Program
{
    static void Main()
    {
        Result r = new Result();

        Console.Write("Enter Marks: ");
        int marks = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter Average: ");
        int avg = Convert.ToInt32(Console.ReadLine());

        bool pass = r.PassMarks(marks);
        string division = r.DivisionMarks(avg);

        Console.WriteLine("Pass Status : " + pass);
        Console.WriteLine("Division : " + division);
    }
}