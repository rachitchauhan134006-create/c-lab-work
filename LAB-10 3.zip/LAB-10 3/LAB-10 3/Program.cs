﻿using System;

class ATM
{
    static void Main()
    {
        int correctPin = 1234;
        int balance = 5000;

        Console.Write("Enter your PIN: ");
        int pin = Convert.ToInt32(Console.ReadLine());

        if (pin == correctPin)
        {
            Console.WriteLine("PIN Verified");

            Console.Write("Enter amount to withdraw: ");
            int withdraw = Convert.ToInt32(Console.ReadLine());

            if (withdraw <= balance)
            {
                balance = balance - withdraw;
                Console.WriteLine("Withdrawal Successful");
                Console.WriteLine("Remaining Balance: " + balance);
            }
            else
            {
                Console.WriteLine("Insufficient Balance");
            }
        }
        else
        {
            Console.WriteLine("Incorrect PIN");
        }
    }
}