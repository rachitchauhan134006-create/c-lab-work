﻿using System;

class Program
{
    static void Main()
    {
        int num, temp, rem, sum = 0;

        Console.Write("Enter a number: ");
        num = int.Parse(Console.ReadLine());

        temp = num;

        while (num > 0)
        {
            rem = num % 10;
            sum = sum + (rem * rem * rem);
            num = num / 10;
        }

        if (temp == sum)
            Console.WriteLine("Armstrong Number");
        else
            Console.WriteLine("Not an Armstrong Number");
    }
}