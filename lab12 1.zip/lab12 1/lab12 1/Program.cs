﻿using System;

class Program
{
    static void Main()
    {
        int[] num = new int[8];
        int positive = 0, negative = 0;

        Console.WriteLine("Enter 8 numbers:");

        for (int i = 0; i < 8; i++)
        {
            num[i] = Convert.ToInt32(Console.ReadLine());

            if (num[i] > 0)
                positive++;
            else if (num[i] < 0)
                negative++;
        }

        Console.WriteLine("Positive numbers: " + positive);
        Console.WriteLine("Negative numbers: " + negative);
    }
}