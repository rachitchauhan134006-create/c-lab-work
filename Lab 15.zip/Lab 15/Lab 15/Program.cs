﻿using System;

class Account
{
    protected int accNo;
    protected double balance;

    public Account(int a, double b)
    {
        accNo = a;
        balance = b;
    }

    public virtual void Deposit(double amount)
    {
        balance += amount;
        Console.WriteLine("Amount Deposited : " + amount);
    }

    public virtual void Withdraw(double amount)
    {
        if (amount <= balance)
        {
            balance -= amount;
            Console.WriteLine("Amount Withdrawn : " + amount);
        }
        else
        {
            Console.WriteLine("Insufficient Balance");
        }
    }

    public void Display()
    {
        Console.WriteLine("Account Number : " + accNo);
        Console.WriteLine("Balance : " + balance);
    }
}

class Savings : Account
{
    double interestRate;

    public Savings(int a, double b, double i) : base(a, b)
    {
        interestRate = i;
    }

    public void AddInterest()
    {
        double interest = balance * interestRate / 100;
        balance += interest;
        Console.WriteLine("Interest Added : " + interest);
    }

    public override void Withdraw(double amount)
    {
        if (amount <= balance)
        {
            balance -= amount;
            Console.WriteLine("Savings Withdraw : " + amount);
        }
        else
        {
            Console.WriteLine("Insufficient Balance in Savings");
        }
    }
}

class Current : Account
{
    double overdraft;

    public Current(int a, double b, double o) : base(a, b)
    {
        overdraft = o;
    }

    public override void Withdraw(double amount)
    {
        if (amount <= balance + overdraft)
        {
            balance -= amount;
            Console.WriteLine("Current Withdraw : " + amount);
        }
        else
        {
            Console.WriteLine("Overdraft Limit Exceeded");
        }
    }
}

class Program
{
    static void Main()
    {
        Savings s = new Savings(101, 5000, 5);
        Current c = new Current(201, 3000, 2000);

        Console.WriteLine("Savings Account");
        s.Display();
        s.Deposit(1000);
        s.Withdraw(2000);
        s.AddInterest();
        s.Display();

        Console.WriteLine("\nCurrent Account");
        c.Display();
        c.Deposit(500);
        c.Withdraw(4000);
        c.Display();
    }
}