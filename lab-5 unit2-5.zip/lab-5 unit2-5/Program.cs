﻿using System;

class Program
{
    static void Main()
    {
        double r, area;

        Console.Write("Enter Radius: ");
        r = Convert.ToDouble(Console.ReadLine());

        area = 3.14 * r * r;

        Console.WriteLine("Area of Circle = " + area);
    }
}
