﻿static void Main()
{
    Employee e1 = new Employee();
    e1.Display();

    Employee e2 = new Employee(101, "Rachit", 25000);
    e2.Display();
}
}
