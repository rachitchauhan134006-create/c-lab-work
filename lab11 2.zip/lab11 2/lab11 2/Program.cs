﻿using System;

class Program
{
    static void Main()
    {
        int min = 0;

        for (int i = 1; i <= 5; i++)
        {
            Console.Write("Enter number " + i + ": ");
            int num = Convert.ToInt32(Console.ReadLine());

            if (i == 1 || num < min)
            {
                min = num;
            }
        }

        Console.WriteLine("Minimum number is: " + min);
    }
}