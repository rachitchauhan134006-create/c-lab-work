﻿using System;

class Program
{
    static void Main()
    {
        int a, b, c;

        Console.Write("Enter first number: ");
        a = int.Parse(Console.ReadLine());

        Console.Write("Enter second number: ");
        b = int.Parse(Console.ReadLine());

        Console.Write("Enter third number: ");
        c = int.Parse(Console.ReadLine());

        int min = a < b ? a : b;
        min = min < c ? min : c;

        Console.WriteLine("Minimum number is: " + min);
    }
}
