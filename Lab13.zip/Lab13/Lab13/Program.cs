﻿using System;

class Rectangle
{
    int length, width;

    public Rectangle()
    {
        length = 0;
        width = 0;
    }

    public Rectangle(int l, int w)
    {
        length = l;
        width = w;
    }

    public int Area()
    {
        return length * width;
    }

    public void Display()
    {
        Console.WriteLine("Length = " + length);
        Console.WriteLine("Width = " + width);
        Console.WriteLine("Area = " + Area());
    }
}

class Program
{
    static void Main()
    {
        Rectangle r1 = new Rectangle();
        Rectangle r2 = new Rectangle(5, 4);

        r1.Display();
        r2.Display();
    }
}