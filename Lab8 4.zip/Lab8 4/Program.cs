﻿using System;

class Program
{
    static void Main()
    {
        string password = "";
        bool valid = false;

        while (!valid)
        {
            Console.Write("Enter password: ");
            password = Console.ReadLine();

            bool hasNumber = false;
            bool hasCapital = false;

            for (int i = 0; i < password.Length; i++)
            {
                if (password[i] >= '0' && password[i] <= '9')
                    hasNumber = true;

                if (password[i] >= 'A' && password[i] <= 'Z')
                    hasCapital = true;
            }

            if (password.Length >= 8 && hasNumber && hasCapital)
            {
                Console.WriteLine("Password Accepted ✅");
                valid = true;
            }
            else
            {
                Console.WriteLine("Invalid Password ❌");
            }
        }
    }
}
