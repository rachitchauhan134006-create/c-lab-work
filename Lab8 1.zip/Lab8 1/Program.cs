﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter first number: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Enter last number: ");
        int b = int.Parse(Console.ReadLine());

        for (int n = a; n <= b; n++)
        {
            if (n > 1)
            {
                int count = 0;

                for (int i = 1; i <= n; i++)
                {
                    if (n % i == 0)
                        count++;
                }

                if (count == 2)
                    Console.Write(n + " ");
            }
        }
    }
}
