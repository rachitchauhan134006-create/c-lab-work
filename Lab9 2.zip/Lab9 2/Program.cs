﻿using System;

class Program
{
    static void Main()
    {
        string text, reverse = "";

        Console.Write("Enter a string: ");
        text = Console.ReadLine();

        for (int i = text.Length - 1; i >= 0; i--)
        {
            reverse = reverse + text[i];
        }

        if (text == reverse)
            Console.WriteLine("Palindrome String");
        else
            Console.WriteLine("Not a Palindrome String");
    }
}