﻿using System;

class Program
{
    static void Main()
    {
        double principal, rate, year, amount, compoundInterest;

        Console.Write("Enter Principal Amount: ");
        principal = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter Rate of Interest: ");
        rate = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter Time (in years): ");
        year = Convert.ToDouble(Console.ReadLine());

        amount = principal * Math.Pow((1 + rate / 100), year);
        compoundInterest = amount - principal;

        Console.WriteLine("Compound Interest = " + compoundInterest);
    }
}
