﻿using System;

class Program
{
    static void Main()
    {
        int num, temp, reverse = 0, rem;

        Console.Write("Enter a number: ");
        num = int.Parse(Console.ReadLine());

        temp = num;

        while (num > 0)
        {
            rem = num % 10;
            reverse = reverse * 10 + rem;
            num = num / 10;
        }

        if (temp == reverse)
            Console.WriteLine("Palindrome Number");
        else
            Console.WriteLine("Not a Palindrome Number");
    }
}