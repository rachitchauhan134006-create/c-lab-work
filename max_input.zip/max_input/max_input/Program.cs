﻿using System;

class MaxNumber
{
    static void Main()
    {
        Console.Write("How many numbers you want to enter: ");
        int n = int.Parse(Console.ReadLine());

        int max = int.MinValue;

        for (int i = 1; i <= n; i++)
        {
            Console.Write("Enter number " + i + ": ");
            int num = int.Parse(Console.ReadLine());

            if (num > max)
                max = num;
        }

        Console.WriteLine("Maximum number is: " + max);
    }
}