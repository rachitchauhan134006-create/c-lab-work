﻿using System;

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Enter First Number: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            int b = Convert.ToInt32(Console.ReadLine());

            int result = a / b;

            Console.WriteLine("Result = " + result);
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Cannot Divide by Zero");
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid Input");
        }

        Console.WriteLine("Program Ended");
    }
}