﻿using System;

class Program
{
    static void Main()
    {
        int n;
        long f = 1;

        Console.Write("Enter number: ");
        n = Convert.ToInt32(Console.ReadLine());

        for (int i = 1; i <= n; i++)
        {
            f = f * i;
        }

        Console.WriteLine(f);
    }
}
