﻿using System;

class BillDiscount
{
    static void Main()
    {
        Console.Write("Enter bill amount: ");
        int bill = int.Parse(Console.ReadLine());

        Console.Write("Enter category (senior / regular / industrial): ");
        string category = Console.ReadLine();

        if (category == "senior")
            bill = bill - (bill * 20 / 100);
        else if (category == "regular")
            bill = bill - (bill * 10 / 100);
        else if (category == "industrial")
            bill = bill - (bill * 30 / 100);

        Console.WriteLine("Final Bill Amount = " + bill);
    }
}